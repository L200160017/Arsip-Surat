<?php
    session_start();
    error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
    $conn = mysqli_connect('localhost','root','','arsip');
    $id_user = $_GET['id'];
    $sql = "SELECT *FROM user where id_user='$id_user' ";
    $query=mysqli_query($conn,$sql);
    $hasil=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>UPDATE</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="date/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 align="center"><b>Ubah User</b></h3>
                    </div>
                    <div class="panel-body">
                        <form action='<?php $_SERVER['PHP_SELF'];?>' method='post' name='update'>
                          <div class="form-group">
                            <div class="form-label-group">
                              <label for="name">Nama User</label>
                              <input type="text" id="name" name="name" class="form-control" required="required" value='<?php echo $hasil['name']; ?>'>
                            </div>
                            <div class="form-label-group">
                              <label for="username">Username</label>
                              <input type="text" id="username" name="username" class="form-control" required="required" value='<?php echo $hasil['username']; ?>'>
                            </div>
                            <div class="form-label-group">
                              <label for="password">Password</label>
                              <input type="text" id="password" name="password" class="form-control" required="required" value='<?php echo $hasil['password']; ?>'>
                            </div>
                            <div class="form-label-group">
                              <label for="password">Divisi</label>
                              <input type="text" id="divisi" name="divisi" class="form-control" required="required" value='<?php echo $hasil['divisi']; ?>'>
                            </div>
                          </div>
                                <!-- Change this to a button or input when using this as a form -->
                              <table align="right">
                                    <tr>
                                    <td>
                                        <input type='button' class="btn btn-outline btn-primary" name='cancel' style="width: auto;" value='Cancel'onClick="javascript:history.back()">
                                    </td> 
                                    <td> 
                                        <input type='submit' class="btn btn-primary btn-block"  
                                        name='ubah' style="width: auto;" value='Ubah'>
                                    </td>
                                    </tr>
                                </table>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
$name     = $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];
$divisi = $_POST['divisi'];
$input    = $_POST['ubah'];

if($input){
    $sql = "update user set name='$name', username = '$username', password = '$password', divisi = '$divisi' where id_user='$id_user' ";
    if ($password = '') {
        $sql = "update user set name='$name', username = '$username', divisi = '$divisi' where id_user='$id_user' ";
    }
  
  $query=mysqli_query($conn,$sql);
  if($query){
    ?>
    <script>alert("User Berhasil Diubah");
    document.location='index.php'</script>
    <?php
  }
}
?>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="date/js/bootstrap-datepicker.js"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</body>
</html>
