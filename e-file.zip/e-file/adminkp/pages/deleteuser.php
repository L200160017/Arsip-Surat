<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect('localhost','root','','arsip');
$id_user = $_GET['del'];
$sql = "DELETE FROM user WHERE id_user = '$id_user' ";
$query = mysqli_query($conn,$sql);
if($query){
	?>
	<script type="text/javascript">
	var result = confirm ("Apakah anda yakin akan menghapus user ini?");
	if (result == true) {
  		document.write ("User berhasil dihapus...");
	}
	else {
  		document.write ("User tetap ada...");
	}
	document.location='index.php'
	</script>
<?php
			}
?>