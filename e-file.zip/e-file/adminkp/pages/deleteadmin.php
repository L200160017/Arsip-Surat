<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect('localhost','root','','arsip');
$id_admin = $_GET['del'];
$sql = "DELETE FROM admin WHERE id_admin = '$id_admin' ";
$query = mysqli_query($conn,$sql);
if($query){
	?>
	<script type="text/javascript">
	var result = confirm ("Apakah anda yakin akan menghapus admin ini?");
	if (result == true) {
  		document.write ("Admin berhasil dihapus...");
	}
	else {
  		document.write ("Admin tetap ada...");
	}
	document.location='daftaradmin.php'
	</script>
<?php
			}
?>