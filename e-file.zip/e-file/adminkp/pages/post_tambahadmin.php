<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$input  = $_POST['input'];
$nama  = $_POST['name'];
$username  = $_POST['username'];
$password   = $_POST['password'];
if($input){
  $conn = mysqli_connect('localhost','root','','arsip');
  $sql = "INSERT INTO admin(username, name, password)VALUES('$username','$nama','$password')";
  $run = mysqli_query($conn,$sql);
  if($run){
    ?>
    <script>alert("Data Berhasil Ditambah");
    document.location='daftaradmin.php'</script>
    <?php
  }
}
?>
