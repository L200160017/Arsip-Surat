<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$input  = $_POST['input'];
$nama  = $_POST['name'];
$username  = $_POST['username'];
$password   = $_POST['password'];
$divisi   = $_POST['divisi'];
if($input){
  $conn = mysqli_connect('localhost','root','','arsip');
  $sql = "INSERT INTO user(username, name, password, divisi)VALUES('$username','$nama','$password','$divisi')";
  $run = mysqli_query($conn,$sql);
  if($run){
    ?>
    <script>alert("Data Berhasil Ditambah");
    document.location='index.php'</script>
    <?php
  }
}
?>
