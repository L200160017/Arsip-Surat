<?php 
session_start();
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect('localhost','root','','arsip');
$username = $_POST['username'];
$password = $_POST['password'];
$admin = $_POST['admin'];
 
$login = mysqli_query($conn,"SELECT * FROM admin WHERE username = '$username' AND password = '$password' ");
$cek = mysqli_num_rows($login);
$gt_user = mysqli_fetch_assoc($login);
 
if($cek > 0){
	session_start();
	$_SESSION['username'] = $username;
	$_SESSION['admin'] = $gt_user['id_admin'];
	$_SESSION['status'] = "login";
	header("location:index.php?ket=1");
}else{
	header("location:gagal.php");
}
 
?>