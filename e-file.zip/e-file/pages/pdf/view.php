<?php
  	$show_file = $_GET['file'];
  	$file = $show_file;
  	$filename = $show_file;
	header('Content-type: application/pdf');
	header('Content-Disposition: inline; filename="' . $filename . '"');
	header('Content-Transfer-Encoding: binary');
	header('Content-Length: ' . filesize($file));
	header('Accept-Ranges: bytes');
	@readfile($file);
?>