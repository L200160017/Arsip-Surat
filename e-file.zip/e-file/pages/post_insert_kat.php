<?php 
session_start();
if (!isset($_SESSION['divisi'])) {
    echo "<script>alert('Silahkan login terlebih dahulu');window.location.href='login.php'</script>";
}
?>

<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$nama_kategori = $_POST['nama_kategori'];
$divisi 	   = $_SESSION['divisi'];
$input         = $_POST['input'];

if($input){
  $conn = mysqli_connect('localhost','root','','arsip');
  $sql = mysqli_query($conn, "INSERT INTO kategori (nama_kategori, id_user)VALUES('$nama_kategori','$divisi')");
?>
<script>alert("Kategori Berhasil Ditambahkan");document.location='kelola_kat.php?ket=<?= $divisi ?>'</script>    
<?php
}
?>