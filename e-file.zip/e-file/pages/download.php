<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect('localhost','root','','arsip');
$dow = $_GET['dow'];
$sql = "select * from surat where id_surat='$dow' ";
$query=mysqli_query($conn,$sql);
$hasil=mysqli_fetch_array($query);

if ($hasil){
	$tanggal = $hasil['tanggal'];
	$perihal = $hasil['perihal'];
	$tujuan  = $hasil['tujuan'];
	$asal    = $hasil['asal'];
	$file    = $hasil['file']; 
}

$filepath = 'pdf/'.$file;
// header("Content-Description: File Transfer"); 
// header("Content-Type: application/octet-stream"); 
// header("Content-Disposition: attachment; filename=" . basename($filepath)); 

// readfile ($filepath);
// exit(); 
header("Content-Type: application/octet-stream");

$path = 'pdf/';
$fullfile = $path.$file;

header("Content-Disposition: attachment; filename=" . Urlencode($perihal.'.pdf'));   
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Description: File Transfer");            
header("Content-Length: " . Filesize($fullfile));
flush(); // this doesn't really matter.
$fp = fopen($fullfile, "r");
while (!feof($fp))
{
    echo fread($fp, 65536);
    flush(); // this is essential for large downloads
} 
fclose($fp);

?>