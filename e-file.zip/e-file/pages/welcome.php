<!DOCTYPE HTML>
<html>
<HEAD>
<title>latihan membuat Background Full</title>
<style type=”text/css”>
html{
background: url(koran.jpg) no-repeat center center fixed;
-webkit-background-size:cover;
-moz-background-size:cover;
-o-background-size:cover;
background-size:cover;
}
</style>
</HEAD>
<body>
</body>
</html>