<?php 
session_start();
if (!isset($_SESSION['divisi'])) {
    echo "<script>alert('Silahkan login terlebih dahulu');window.location.href='login.php'</script>";
}
?>

<?php 
session_start();
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect('localhost','root','','arsip');
$username = $_POST['username'];
$password = $_POST['password'];
$divisi = $_POST['divisi'];
 
$login = mysqli_query($conn,"SELECT * FROM user WHERE username = '$username' AND password = '$password' AND divisi = '$divisi' ");
$cek = mysqli_num_rows($login);
$gt_user = mysqli_fetch_assoc($login);
 
if($cek > 0){
	session_start();
	$_SESSION['username'] = $username;
	$_SESSION['divisi'] = $gt_user['id_user'];
	$_SESSION['status'] = "login";
	header("location:index.php?ket=1");
}else{
	header("location:gagal.php");
}
 
?>