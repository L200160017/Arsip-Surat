<?php 
session_start();
if (!isset($_SESSION['divisi'])) {
    echo "<script>alert('Silahkan login terlebih dahulu');window.location.href='login.php'</script>";
}
?>

<?php
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect('localhost','root','','arsip');
$del = $_GET['del'];
$sql = "delete from surat where id_surat='$del' ";
$query = mysqli_query($conn,$sql);
if($query){
	?>
	<script type="text/javascript">
	var result = confirm ("Apakah yakin akan menghapus data ini?");
	if (result == true) {
  		document.write ("Data berhasil dihapus...");
	}
	else {
  		document.write ("Data tetap ada...");
	}
	document.location='index.php?ket=<?= $_GET["ket"] ?>'
	</script>
<?php
			}
?>