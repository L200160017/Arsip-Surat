<?php 
session_start();
if (!isset($_SESSION['divisi'])) {
    echo "<script>alert('Silahkan login terlebih dahulu');window.location.href='login.php'</script>";
}

if (!isset($_GET['ket'])) {
    header("location:index.php?ket=1");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>INDEX</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                </button>
                <a class="navbar-brand" href="index.php?ket=1"><b>SOLOPOS</b></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                        <a href="logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?')"><i class="fa fa-user fa-fw"></i> Logout</a>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                       <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i> Kategori Surat<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <?php
                                    $divisi = $_SESSION['divisi'];
                                    $conn  = mysqli_connect('localhost','root','','arsip');
                                    $getMenu = mysqli_query($conn,"SELECT *FROM kategori WHERE id_user = '$divisi'");
                                    while ($gt = mysqli_fetch_assoc($getMenu)) {
                                ?>
                                    <li>
                                        <a href="index.php?ket=<?= $gt['id_kategori'] ?>"><?= $gt['nama_kategori'] ?></a>
                                    </li>
                                <?php
                                    }
                                ?>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li><a href="kelola_kat.php"><i class="fa fa-gears fa-fw"></i> Kelola Kategori</a></li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <?php
                    if (!isset($_GET['ket'])) {
                        $kat = 1;
                    }else{
                        $kat = $_GET['ket'];
                    }
                    $gdivisi = mysqli_query($conn,"SELECT divisi FROM user WHERE id_user = '$divisi'");
                    $getdivisi = mysqli_fetch_assoc($gdivisi);

                    $kategori = mysqli_query($conn,"SELECT nama_kategori FROM kategori WHERE id_kategori = '$kat'");
                    $getkategori = mysqli_fetch_assoc($kategori);
                    ?>
                    <font face="Berlin_Sans_FB_Demi"><h1 class="page-header" align="center">DIVISI <?= $getdivisi['divisi'] ?></h1></font>
                    <h5 align="center"><b>SOLOPOS</b></h5>
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <?= $getkategori['nama_kategori']; ?>
                        </div>

                            
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <a class="btn btn-primary" href="insert.php?ket=<?= $_GET['ket'];?>"><i class="fa fa-plus fa-fw"></i> Tambah Surat</a>
                                <thead><br>
                                    <tr><br>
                                        <th width="400">Perihal</th>
                                        <th>Tanggal</th>
                                        <th>Tujuan</th>
                                        <th>Asal</th>
                                        <th>File
                                        <th width="140">Aksi</th>
                                    </tr>
                                </thead>
                  <?php
                  error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
                  $kategori_surat = $_GET['ket'];
                  $sql   = "select * from surat where id_user='$divisi' AND id_kategoriFK = '$kategori_surat' ";
                  $query = mysqli_query($conn,$sql);
                  while($data=mysqli_fetch_array($query)){
                  echo "
                  <tr>
                    <td>$data[perihal]</td>
                    <td>".date('d-m-Y', strtotime($data['tanggal']))."</td>
                    <td>$data[tujuan]</td>
                    <td>$data[asal]</td>
                    <td>$data[file]</td>
                    <td align='center'>
                        <a class='btn btn-primary btn-circle' target='_blank' href='pdf/view.php?file=$data[file]'>
                        <i class='glyphicon glyphicon-folder-open'></i></a>
                        <a class='btn btn-success btn-circle' target='_blank' href='download.php?dow=$data[id_surat]'>
                        <i class='glyphicon glyphicon-download-alt'></i></a>
                        <a class='btn btn-warning btn-circle' href='update.php?upd=$data[id_surat]&ket=$_GET[ket]'>
                        <i class='glyphicon glyphicon-pencil'></i></a>
                        <a class='btn btn-danger btn-circle' href='delete.php?del=$data[id_surat]&ket=$_GET[ket]'>
                        <i class='glyphicon glyphicon-trash'></i></a></td>
                   </tr>
                   ";
                    }
                    ?>
                            <tbody>
                         </tbody>
                    </table>
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
    <script>
    // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })
    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>

</body>
</html>
