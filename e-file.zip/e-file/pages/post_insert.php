<?php 
session_start();
if (!isset($_SESSION['divisi'])) {
    echo "<script>alert('Silahkan login terlebih dahulu');window.location.href='login.php'</script>";
}
?>

<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$perihal  = $_POST['perihal'];
$tanggal  = $_POST['tanggal'];
$tujuan   = $_POST['tujuan'];
$asal     = $_POST['asal'];
$kategori_surat     = $_GET['ket'];

// ambil data file
$namaFile = $_FILES['file']['name'];
$namaSementara = $_FILES['file']['tmp_name'];
$divisi = $_SESSION['divisi'];

// tentukan lokasi file akan dipindahkan
$dirUpload = "pdf/".$namaFile;
$fileType = strtolower(pathinfo($dirUpload,PATHINFO_EXTENSION));
$input    = $_POST['input'];

if($input){
  if($fileType != "pdf") {
    ?>
    <script type="text/javascript">
      alert("File harus dalam format PDF");
      window.history.go(-1);
    </script>
    <?php
  }else{
    $conn = mysqli_connect('localhost','root','','arsip');
    $sql = "insert into surat (id_kategoriFK,id_user,tanggal,perihal,tujuan,asal,file)
    values('$kategori_surat','$divisi','$tanggal','$perihal','$tujuan','$asal','$namaFile')";
    $run = mysqli_query($conn,$sql);

    if($run){
      move_uploaded_file($_FILES['file']['tmp_name'], $dirUpload);
      //echo json_encode($_FILES['file']);
      ?>
      <script>alert("Data Berhasil Ditambah");
      document.location='index.php?ket=<?= $kategori_surat ?>'</script>
      <?php
    }
  }
}
?>
